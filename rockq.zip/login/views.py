from django.shortcuts import render
from django.http import HttpResponse, JsonResponse
import json
from django.views import View
from database.models import userdb

class test(View):
    def get(self, request):
        id = request.GET['id']
        pwd = request.GET['password']
        
        if (id == 'server') and (pwd == 'password'):
            return HttpResponse("T", "201")
        else:
            return HttpResponse("F", "202")

    def post(self, request):
        id = request.POST['id']
        pwd = request.POST['password']

        if (id == 'server') and (pwd == 'password'):
            return HttpResponse("T", "201")
        else:
            return HttpResponse("F", "202")
       
class signup(View):
    def get(self, request):
        id = request.GET['phonenumber']
        pwd = request.GET['password']
        type = request.GET['type']

        user = userdb(user_id = id,
                pwd = pwd,
                user_type = type)
        user.save()
        return HttpResponse("T","202")

    def post(self, request):
        id = request.POST['phonenumber']
        pwd = request.POST['password']
        type = request.POST['type']

        user = userdb(user_id = id,
                pwd = pwd,
                user_type = type)
        user.save()
        return HttpResponse("T","202")

class checkid(View):
    def get(slef, request):
        id = request.GET['phonenumber']
        users = userdb.objects.all()
        for user in users:
            if user.user_id == id :
                return HttpResponse("T","202")

        return HttpResponse("F", "202")

    def post(self, request):
        id = request.POST['phonenumber']
        users = userdb.objects.all()
        for user in users:
            if user.user_id == id:
                return HttpResponse("T", "202")
        return HttpResponse("F", "202")

class login(View):
    def get(self, request):
        id = request.GET['phonenumber']
        pwd = request.GET['password']
        users = userdb.objects.all()
        for user in users:
            if user.user_id == id:
                if user.pwd == pwd :
                    return HttpResponse(user.user_type, "202")
                return HttpResponse("3", "202")
        return HttpResponse("3", "202")

    def post(self, request):
        id = request.POST['phonenumber']
        pwd = request.POST['password']
        users = userdb.objects.all()
        for user in users:
            if user.user_id == id:
                if user.pwd == pwd:
                    return HttpResponse(user.user_type, "202")
                return HttpResponse("3", "202")
            return HttpResponse("3", "202")
# Create your views here.
