from django.db import models

class userdb(models.Model):
    user_id = models.CharField(max_length=15)
    pwd = models.CharField(max_length=30)
    user_type = models.CharField(max_length=4)


# Create your models here.
